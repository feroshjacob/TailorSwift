package cb.datascience.tailorswift

import cb.webscalding.test.WebScaldingTest
import com.twitter.scalding.Source
import scala.io.Source


class WordCountTest extends WebScaldingTest {
  
  
  test("wordcount"){
        val outFile = ".tests/out.txt"
     val inFile = ".tests/infile"

     createFile(Seq("ferosh jacob", "jacob joseph"), inFile)
      
     val arguments = Map("input"->inFile, "output"-> outFile)
     val job =  new WordCountJob(createArguments(arguments))
     launch(job)
     val lines =Source.fromFile(outFile).getLines.toSeq
     lines should have size (3)
     lines  should contain ("jacob\t2")
  }
  

}
