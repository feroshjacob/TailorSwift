#!/bin/bash
hadoop jar WordCount-assembly-0.0.1.jar cb.datascience.tailorswift.WordCountJob --hdfs --input testwordcount --output output 
