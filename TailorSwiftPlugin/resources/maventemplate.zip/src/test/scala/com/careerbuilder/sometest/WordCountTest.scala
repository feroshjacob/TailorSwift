package com.careerbuilder.sometest

import scala.io.Source

import cb.webscalding.test.WebScaldingTest

class WordCountTest extends WebScaldingTest {

  test("legacy companies") {

    val outFile = createOutPutFile();

    val inFile = "input"
      createFile(Seq("Hello World"), inFile)
    val args = Map("output" -> outFile, "input"-> inFile)
    launch(new WordCountJob(createArguments(args)))
    val linesOut = Source.fromFile(outFile).getLines.toSeq

    linesOut should have size (2)
    linesOut should contain ("Hello\t1")
     linesOut should contain ("World\t1")
   
   
  }

}