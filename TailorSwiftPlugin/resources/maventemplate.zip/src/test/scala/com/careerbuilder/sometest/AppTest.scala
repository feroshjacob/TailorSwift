package com.careerbuilder.sometest
import org.scalatest.FunSuite
import org.scalatest.matchers.ShouldMatchers
import org.scalatest.FunSuite



class AppTest  extends FunSuite with ShouldMatchers{

  
  test("example") {
     1+2 should be  equals(3)
  }
 
}


